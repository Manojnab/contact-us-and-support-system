export class Employee {
    _id: string;
    name: string;
    position: string;
    salary: number;
    office: string;
    
}
