import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-adcrim',
  templateUrl: './rmmtravels.component.html',
  styleUrls: ['./rmmtravels.component.css']
})
export class RmmtravelsComponent implements OnInit {
  

  constructor() { }

  ngOnInit() {
  }

}
