import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-adcrim',
  templateUrl: './adcrim.component.html',
  styleUrls: ['./adcrim.component.css']
})
export class AdcrimComponent implements OnInit {
  

  constructor() { }

  ngOnInit() {
  }

}
