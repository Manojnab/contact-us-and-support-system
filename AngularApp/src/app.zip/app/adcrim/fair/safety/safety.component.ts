import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-adcrim',
  templateUrl: './safety.component.html',
  styleUrls: ['./safety.component.css']
})
export class SafetyComponent  implements OnInit {
  

  constructor() { }

  ngOnInit() {
  }

}
