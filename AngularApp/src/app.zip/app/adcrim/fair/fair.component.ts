import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-adcrim',
  templateUrl: './fair.component.html',
  styleUrls: ['./fair.component.css']
})
export class FairComponent implements OnInit {
  

  constructor() { }

  ngOnInit() {
  }

}
