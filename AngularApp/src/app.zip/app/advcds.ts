import { Time } from '@angular/common';

export class Advcs {
    _id: number;
    name: String;
    email: String;
    phone: number;
    feed: String;
    hh: number;
    mm: number;
    type: string;
    day:string;


  }